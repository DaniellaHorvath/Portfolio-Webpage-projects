import sqlite3 as sql  # import sqlite modul and assing it to an alias sql

# To use the module (sqlite3 as sql), start by creating a database connection object
dbCon = sql.connect("filmflix.db")

# Create a cursor object to connect the database and execute sql statement/queries
dbCursor = dbCon.cursor()
