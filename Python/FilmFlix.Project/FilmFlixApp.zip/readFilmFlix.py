from connect import *


def readData():
    dbCursor.execute("SELECT * FROM tblFilms")

    allRecords = dbCursor.fetchall()

    for eachrecord in allRecords:
        print(eachrecord)


if __name__ == "__main__":
    readData()
