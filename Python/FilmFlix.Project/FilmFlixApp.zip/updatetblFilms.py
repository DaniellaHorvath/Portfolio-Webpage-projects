from connect import *


def updateData():
    idfield = input("Enter the filmID of the record to be updated: ")

    fieldName = input(
        "Enter Title or YearReleased or Rating or Duration or Genre as a field name: ").title()

    fieldValue = input(f"Enter the value for the {fieldName} field: ")

    # print(fieldValue)

    fieldValue = "'" + fieldValue + "'"
    # print(fieldValue)

    dbCursor.execute(
        f"UPDATE tblFilms SET {fieldName} = {fieldValue} WHERE filmID = {idfield}")
    dbCon.commit()
    print(f"Record {idfield} updated in the tblFilms table")


if __name__ == "__main__":
    updateData()
