# from connect import *


# def deleteRecord():
#     idField = input("Enter the filmID of the record to be deleted: ")

#     dbCursor.execute(f"DELETE FROM tblFilms WHERE filmID = {idField}")
#     dbCon.commit()

#     print(f"Record {idField} deleted from the tblFilms table")


# if __name__ == "__main__":
#     deleteRecord()

from connect import *


def deleteRecord():
    idField = input("Enter the filmID of the record to be deleted: ")

    confirmDelete = input(
        f"Are you sure you want to delete record {idField}: Y/N ")
    if confirmDelete == "Y":
        dbCursor.execute(f"DELETE FROM tblFilms WHERE filmID = {idField}")

        dbCon.commit()
        print(f"Record {idField} deleted from the tblFilms table")
    else:
        print(f"Record {idField} will not be deleted from the tblFilms table")


if __name__ == "__main__":
    deleteRecord()
