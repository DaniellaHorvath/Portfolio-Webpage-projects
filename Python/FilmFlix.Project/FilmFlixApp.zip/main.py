import readFilmFlix
import addtblFilms
import updatetblFilms
import deletetblFilms
from reports import genreReport, yearReleasedReport, ratingReport, printAll
####
###


def menuFiles():
  with open("optionsmenu.txt") as mainMenu:
    userMainmenu = mainMenu.read()
  with open("report.txt") as subMenu:
    userSubMenu = subMenu.read()
  return userMainmenu, userSubMenu


userChoices = menuFiles()

# print(userChoices[0])


# function for the optionsMen
def optionsmenu():
  options = 0
  optionsList = ["1", "2", "3", "4", "5"]

  userChoices = menuFiles()

  while options not in optionsList:
    print(userChoices[0])
    options = input("Enter an option from the films main options menu above: ")
    if options not in optionsList:
      print(f"{options} is not a valid option in the films menu!")
  return options


print(optionsmenu)
# function for the report sub menu


def reportSubMenu():
  options = 0
  optionsList = ["1", "2", "3", "4", "5"]
  reportChoices = menuFiles()

  while options not in optionsList:
    print(userChoices[1])
    options = input("Enter an option from the reports sub menu above: ")
    if options not in optionsList:
      print(f"{options} is not valid choice in the reports sub menu!")
  return options


print(reportSubMenu)

mainProgram = True
while mainProgram:
  mainMenu = optionsmenu()

  if mainMenu == "1":
    addtblFilms.insertData()
  elif mainMenu == "2":
    deletetblFilms.deleteRecord()
  elif mainMenu == "3":
    updatetblFilms.updateData()
  elif mainMenu == "4":
    readFilmFlix.readData()
  elif mainMenu == "5":
    reportProgram = True
    while reportProgram:
      reportMenu = reportSubMenu()
      if reportMenu == "1":
        printAll()
      elif reportMenu == "2":
        genreReport()
      elif reportMenu == "3":
        yearReleasedReport()
      elif reportMenu == "4":
        ratingReport()

      else:
        reportProgram = False
        input("Press enter to return to the films menu")

  else:
    mainProgram = False
input("Press enter to exit the Films App")
