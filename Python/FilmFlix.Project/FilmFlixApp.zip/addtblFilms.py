from connect import *


def insertData():
    FilmTitle = input("Enter Film Title: ")
    FilmYearReleased = input("Enter Film Year Released: ")
    FilmRating = input("Enter Film Rating: ")
    FilmDuraction = input("Enter Film Duraction: ")
    FilmGenre = input("Enter film Genre: ")

    dbCursor.execute("INSERT INTO tblFilms VALUES (NULL,?,?,?,?,?)",
                     (FilmTitle, FilmYearReleased, FilmRating, FilmDuraction, FilmGenre))

    dbCon.commit()
    print(f"{FilmTitle} inserted into the films table")  # testing


if __name__ == "__main__":
    insertData()  # call the function
