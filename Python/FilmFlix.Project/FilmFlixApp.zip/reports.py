from connect import *


def printAll():
    dbCursor.execute("SELECT * FROM tblFilms")
    searchData = dbCursor.fetchall()

    # loop through all records held as a list in the allRecords variable
    for records in searchData:
        # display each record
        print(records)

# printAll()


def genreReport():
    userData = input("Please enter the genre: ").title()
    dbCursor.execute(f"SELECT * FROM tblFilms WHERE genre = '{userData}'")

    searchData = dbCursor.fetchall()

    # loop through all records held as a list in the allRecords variable
    for records in searchData:
        # display each record
        print(records)


# genreReport()


def yearReleasedReport():

    userData = input(f"Please enter the years of release: ")
    dbCursor.execute(
        f"SELECT * FROM tblFilms WHERE yearReleased = '{userData}'")

    searchData = dbCursor.fetchall()

    # loop through all records held as a list in the allRecords variable
    for records in searchData:
        # display each record
        print(records)


# yearReleasedReport()


def ratingReport():
    userData = input("Please enter rating: ").upper()
    dbCursor.execute(f"SELECT * FROM tblFilms WHERE rating = '{userData}'")
    searchData = dbCursor.fetchall()

    # loop through all records held as a list in the allRecords variable
    for records in searchData:
        # display each record
        print(records)
# ratingReport()
